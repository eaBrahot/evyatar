//208060855 Evyatar Altman

/**
 * the class that binds every things together.
 */
public class Ass3Game {
    /**
     * the main that operates everything.
     * @param args from the cmd
     */
    public static void main(String[] args) {
        Game game = new Game();
        game.initialize();
        game.run();
    }
}
