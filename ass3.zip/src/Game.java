//208060855 Evyatar Altman

import biuoop.DrawSurface;
import biuoop.GUI;
import biuoop.Sleeper;

import java.awt.Color;
import java.util.Random;

/**
 * This class operates the whole game, include his Sprites and collidable objects, by the game environment.
 */
public class Game {
    public static final double EPSILON = 1e-10;
    private SpriteCollection sprites;
    private GameEnvironment environment;
    private GUI gui;
    private Sleeper sleeper;
    private biuoop.KeyboardSensor keyboard;
    private Paddle paddle;
    //the boundaries of the game
    public static final int WIDTH = 800;
    public static final int HEIGHT = 600;
    //the height of the boundaries up and down
    private static final int BON_H = 50;
    //the width of the boundaries left and right
    public static final int BON_W = 50;
    //the width of regular block
    private static final int BLOCK_W = 50;
    //the height of regular block
    private static final int BLOCK_H = 25;
    //the radiuse of the ball
    private static final int R = 5;
    //number of blocks in  a row
    private static final int BLOCK_NUM = 12;
    //number of rows
    private static final int ROWS = 6;
    //x start of the first block
    private static final double START_X = WIDTH - BLOCK_W - BON_W;
    //y start of the first block
    private static final double START_Y = 2 * BON_W;
    //number of balls
    private static final int BALL_N = 2;
    //max speed
    private static final int SPEED = 5;
    //max radians
    private static final double MAX_RAD = 2 * 3.14;
    /**
     * constructor for new Game obj.
     */
    public Game() {
        this.environment  = new GameEnvironment();
        this.sprites = new SpriteCollection();
        this.gui = new GUI("Game ver 1", WIDTH, HEIGHT);
        this.sleeper = new Sleeper();
        this.keyboard = gui.getKeyboardSensor();
    }

    /**
     * add new collidble object to the game environment.
     * @param c Collidable, the given object
     */
    public void addCollidable(Collidable c) {
        this.environment.addCollidable(c);
    }

    /**
     * add new Sprite object to the sprite collection.
     * @param s new Sprite object
     */
    public void addSprite(Sprite s) {
        this.sprites.addSprite(s);
    }

    /**
     * generate random double number between min and max.
     * @param min double
     * @param max double
     * @return random double
     */
    public static double nextDoubleBetween(double min, double max) {
        return (new Random().nextDouble() * (max - min)) + min;
    }

    /**
     * Initialize a new game: create the Blocks and Ball (and Paddle)
     * and add them to the game.
     */
    public void initialize() {
        //create the background
        Color darkBlue = new Color(0, 5, 100);
        Block background = new Block(new Rectangle(new Point(0, 0), WIDTH, HEIGHT), darkBlue);
        //create the four boundaries as blocks on the sides
        Block upBoundary = new Block(new Rectangle(new Point(0, 0), WIDTH, BON_H), Color.GRAY);
        //the left is between the up and down boundaries, so his height decreased by their heights
        //and his up point start after the up.
        Block leftBoundary = new Block(new Rectangle(new Point(0, BON_H), BON_W,
                HEIGHT - 2 * BON_H), Color.GRAY);
        //the y point of the down was calculates by the end of the screen - his height
        Block downBoundary = new Block(new Rectangle(new Point(0, HEIGHT - BON_H), WIDTH, BON_H),
                Color.GRAY);
        //the right is between the up and down boundaries, so his height decreased by their width
        //his x point was calculates by the end of the screen to the right- his width, his y start after the up boundary
        Block rightBoundary = new Block(new Rectangle(new Point(WIDTH - BON_W, BON_H),
                BON_W, HEIGHT - 2 * BON_H),
                Color.GRAY);
        Color[] arryC = {Color.blue, Color.red, Color.yellow, Color.orange, Color.green, Color.cyan};
        Block[] boundaries = {background, upBoundary, leftBoundary, downBoundary, rightBoundary};
        //add the boundaries to the game
        for (Block i : boundaries) {
            i.addToGame(this);
        }

        //add the balls, create their start point inside the boundaries
        Ball ball;
        for (int i = 0; i < BALL_N; i++) {
            ball = new Ball(R + BON_W + 1, HEIGHT - (R + BON_H), R, arryC[i], this.environment);
            //give random velocity
            Velocity v = Velocity.fromAngleAndSpeed(nextDoubleBetween(0, MAX_RAD), SPEED);
            ball.setVelocity(v);
            ball.addToGame(this);
        }

        Block newBlock;
        double y = START_Y;
        //add six rows of blocks, start from the right boundary
        for (double i = 0; i < ROWS; i++) {
            Color rowColor = arryC[(int) i];
            double x = START_X;
            for (double j = 0; j < BLOCK_NUM - i; j++) {
                newBlock = new Block(new Rectangle(new Point(x, y), BLOCK_W, BLOCK_H), rowColor);
                newBlock.addToGame(this);
                x -= BLOCK_W;
            }
            y += BLOCK_H;
        }
        //add the paddle
        this.setPaddle(new Paddle(this.keyboard));
        this.paddle.addToGame(this);
    }
    /**
     * Run the game -- start the animation loop.
     */
    public void run() {
        //makes the animation smooth
        int framesPerSecond = 60;
        //there for
        int millisecondsPerFrame = 1000 / framesPerSecond;
        while (true) {
            long startTime = System.currentTimeMillis(); // timing
            //create the surface
            DrawSurface d = gui.getDrawSurface();
            //draw all the sprites
            this.sprites.drawAllOn(d);
            gui.show(d);
            //move the sprites
            this.sprites.notifyAllTimePassed();

            // timing
            long usedTime = System.currentTimeMillis() - startTime;
            long milliSecondLeftToSleep = millisecondsPerFrame - usedTime;
            if (milliSecondLeftToSleep > 0) {
                sleeper.sleepFor(milliSecondLeftToSleep);
            }
        }
    }

    /**
     * getter to get the width of the boundaries.
     * @return int width of the boundaries
     */
    public int getBoundaryWidth() {
        return BON_W;
    }

    /**
     * getter to get the width of the board.
     * @return int width of the board
     */
    public int getBoardWidth() {
        return WIDTH;
    }

    /**
     * getter to get the height of the board.
     * @return int height of the board
     */
    public int getBoardHeight() {
        return HEIGHT;
    }

    /**
     * set new gameEnvironment.
     * @param gameEnvironment new GameEnvironment
     */
    public void setEnvironment(GameEnvironment gameEnvironment) {
        this.environment = gameEnvironment;
    }

    /**
     * set new sprites collection.
     * @param spriteCollection new SpriteCollection
     */
    public void setSprites(SpriteCollection spriteCollection) {
        this.sprites = spriteCollection;
    }

    /**
     * set new paddle.
     * @param paddle new Paddle
     */
    public void setPaddle(Paddle paddle) {
        this.paddle = paddle;
    }
}
