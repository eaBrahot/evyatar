// 208060855 Evyatar Altman

import biuoop.DrawSurface;
import biuoop.GUI;
import biuoop.KeyboardSensor;

import java.awt.Color;

/**
 * class to create the paddle in the game, which the player uses to bounce the ball.
 */
public class Paddle implements Sprite, Collidable {
    private biuoop.KeyboardSensor keyboard;
    //the sizes of the paddle
    private static final int WIDTH = 80;
    private static final int HEIGHT = 25;
    //his upLeft point
    private static final double START_X = 360;
    private static final double START_Y = 520;
    private static final Color COLOR = Color.white;
    private static final int BOARD_WIDTH = 800;
    //his progress left\right per press
    private static final int PROGRESS = 2;
    //max speed of the ball
    private static final int MAX_SPEED = 5;
    //te block that represent the paddle
    private Block paddle;
    private static final int BOUNDARY_WIDTH = 50;

    /**
     * constructor to build the paddle with KeyboardSensor.
     * @param keyboard the keyboard sensor
     */
    public Paddle(KeyboardSensor keyboard) {
        this.paddle = new Block(new Rectangle(new Point(START_X, START_Y), WIDTH, HEIGHT), COLOR);
        this.keyboard = keyboard;
    }

    /**
     * constructor to build the paddle with KeyboardSensor and gui.
     * @param keyboard the keyboard sensor
     * @param gui new GUI
     */
    public Paddle(GUI gui, KeyboardSensor keyboard) {
        this.paddle = new Block(new Rectangle(new Point(START_X, START_Y), WIDTH, HEIGHT), COLOR);
        this.keyboard = keyboard;
    }

    /**
     * move the paddle left if the player presses on the left arrow.
     */
    public void moveLeft() {
        //prepare the x
        double x = this.paddle.getBlock().getUpperLeft().getX();
        //check if it got to the left boundary
        if (x <= BOUNDARY_WIDTH) {
            return;
        }
        //add value in left direction
        if (this.keyboard.isPressed(keyboard.LEFT_KEY)) {
            //check if going left would pass the boundary, change to the edge of the boundary
            if ((x - PROGRESS) <= BOUNDARY_WIDTH) {
                this.paddle.setX(BOUNDARY_WIDTH);
            } else {
                //progress left
                this.paddle.setX(x - PROGRESS);
            }
        }
    }

    /**
     * move the paddle right if the player presses on the right arrow.
     */
    public void moveRight() {
        //prepare the x
        double x = this.paddle.getBlock().getUpperLeft().getX();
        //check if the paddle got to the right boundary
        if (x + WIDTH >= BOARD_WIDTH - BOUNDARY_WIDTH) {
            return;
        }
        //check if the progress would get the paddle into the boundary
        if (this.keyboard.isPressed(keyboard.RIGHT_KEY)) {
            //check if going right would pass the boundary, change to the edge of the boundary
            if ((x + WIDTH + PROGRESS) >= BOARD_WIDTH - BOUNDARY_WIDTH) {
                this.paddle.setX(BOARD_WIDTH - (BOUNDARY_WIDTH + WIDTH));
            } else {
                //progress right
                this.paddle.setX(x + PROGRESS);
            }
        }
    }

    /**
     * method to notify the paddle to move.
     */
    public void timePassed() {
        this.moveLeft();
        this.moveRight();
    }

    /**
     * method to draw the paddle on a given surface.
     * @param d DrawSurface
     */
    public void drawOn(DrawSurface d) {
        this.paddle.drawOn(d);
    }

    /**
     * Return the block of the paddle in case of collision with the ball.
     * @return Rectangle obj
     */
    public Rectangle getCollisionRectangle() {
        return this.paddle.getBlock();
    }

    /**
     * changing the ball's directory if it hade hit the paddle.
     * @param collisionPoint Point
     * @param currentVelocity Velocity
     * @return new velocity for the ball
     */
    public Velocity hit(Point collisionPoint, Velocity currentVelocity) {
        //dividing the paddle to 5 region so the ball bounce in different angle from each region on the paddle
        //the y value in every region is the same as the paddle
        double paddleX = this.paddle.getBlock().getUpperLeft().getX();
        double paddleY = this.paddle.getBlock().getUpperLeft().getY();
        double xColl = collisionPoint.getX();
        double yColl = collisionPoint.getY();
        double regionWidth = this.WIDTH / 5;
        double region1 = paddleX + regionWidth;
        double region2 = paddleX + 2 * regionWidth;
        double region3 = paddleX + 3 * regionWidth;
        double region4 = paddleX + 4 * regionWidth;
        double speedBall = currentVelocity.getSpeed();
        //if the hit was above
        if (yColl <= paddleY) {
            //if the hit was in the most left side of the paddle, return in 300 angle (-60)
            if (xColl <= region1) {
                return Velocity.fromAngleAndSpeed(300, speedBall);
            }
            //in the second left but not most, 330 angle (-30)
            if (xColl <= region2) {
                return Velocity.fromAngleAndSpeed(330, speedBall);
            }
            //if hit the middle, angle 0
            if (xColl <= region3) {
                return this.paddle.hit(collisionPoint, currentVelocity);
            }
            //in the second right but not most, angle 30
            if (xColl <= region4) {
                return Velocity.fromAngleAndSpeed(30, speedBall);
            }
            //most right, angle 60
            return Velocity.fromAngleAndSpeed(60, speedBall);
        }
        return this.paddle.hit(collisionPoint, currentVelocity);
    }

    /**
     * Add this paddle to the game.
     * @param g  our Game obj
     */
    public void addToGame(Game g) {
        g.addCollidable(this);
        g.addSprite(this);
    }
}
