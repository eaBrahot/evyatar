//208060855 Evyatar Altman

import biuoop.DrawSurface;

import java.util.ArrayList;
import java.util.List;

/**
 * This class take care on all the sprites in the game and operates them when needed.
 */
public class SpriteCollection {
    private List<Sprite> arrSprite;

    /**
     * constructor to create array to store all the sprites.
     */
    public SpriteCollection() {
        this.arrSprite = new ArrayList<>();
    }

    /**
     * method that add a sprite to the array.
     * @param s  a given Sprite
     */
    public void addSprite(Sprite s) {
        this.arrSprite.add(s);
    }
    /**
     * call timePassed() on all sprites.
     */
    public void notifyAllTimePassed() {
        for (Sprite i : this.arrSprite) {
            i.timePassed();
        }
    }

    /**
     * call drawOn(d) on all sprites on d, the given surface.
     * @param d DrawSurface, the given surface.
     */
    public void drawAllOn(DrawSurface d) {
        for (Sprite i : this.arrSprite) {
            i.drawOn(d);
        }
    }
}

