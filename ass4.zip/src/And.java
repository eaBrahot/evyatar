//Evyatar Altman 208060855

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * class that represent And expression.
 */
public class And extends BinaryExpression {
    private static final String AND = "&";
    private Expression left;
    private Expression right;

    /**
     * constructor with two expression.
     * @param left the left expression
     * @param right the right expression
     */
    public And(Expression left, Expression right) {
        this.left = left;
        this.right = right;
    }

    @Override
    public Expression sortString() {
        Expression left = this.left.sortString();
        Expression right = this.right.sortString();
        int first = 0;
        int result = left.toString().compareTo(right.toString());
        //if the left is lower
        if (result < 0) {
            return new And(right, left);
        }
        //without change
        return new And(left, right);
    }
    @Override
    public Boolean evaluate(Map<String, Boolean> assignment) throws Exception {
        return left.evaluate(assignment) && right.evaluate(assignment);
    }

    @Override
    public Boolean evaluate() throws Exception {
        return left.evaluate() && right.evaluate();
    }
    @Override
    public String toString() {
        return "(" + left.toString() + " " + AND + " " + right.toString() + ")";
    }

    @Override
    public List<String> getVariables() {
        List<String> marge = new ArrayList<>();
        marge.addAll(left.getVariables());
        //check if i exists in the left operand
        for (String i : right.getVariables()) {
            if (!left.getVariables().contains(i)) {
                marge.add(i);
            }
        }
        return marge;
    }
    @Override
    public Expression assign(String var, Expression expression) {
        return new And(left.assign(var, expression), right.assign(var, expression));
    }

    @Override
    public Expression nandify() {
        //x&y equals to (x A y) A (x A y)
        return new Nand(new Nand(left.nandify(), right.nandify()), new Nand(left.nandify(), right.nandify()));
    }

    @Override
    public Expression norify() {
        //x&y equals to (x V x) A (y V y)
        return new Nor(new Nor(left.norify(), left.norify()), new Nor(right.norify(), right.norify()));
    }

    @Override
    public Expression simplify() {
        Expression left = this.left.simplify();
        Expression right = this.right.simplify();
        //x & 1 = x
        if (right.toString().equals("T")) {
            return left.createCopy();
        }

        //1 & x = x
        if (left.toString().equals("T")) {
            return right.createCopy();
        }
        //x & 0 = 0
        if (right.toString().equals("F")) {
            return new Val(false);
        }

        //0 & x = 0
        if (left.toString().equals("F")) {
            return new Val(false);
        }
        //x & x = x
        if (right.sortString().toString().equals(left.sortString().toString())) {
            return left.createCopy();
        }
        //return the expression without change
        return new And(left, right);
    }

    @Override
    public Expression createCopy() {
        return new And(left.createCopy(), right.createCopy());
    }
}
