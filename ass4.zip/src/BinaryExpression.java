//Evyatar Altman 208060855


/**
 * class to represent binary expression.
 */
public abstract class BinaryExpression extends BaseExpression {
}
