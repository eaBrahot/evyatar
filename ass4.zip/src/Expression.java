//Evyatar Altman 208060855

import java.util.List;
import java.util.Map;

/**
 * interface that define logical expressions.
 */
public interface Expression {

    /** Evaluate the expression using the variable values provided
    in the assignment, and return the result. If the expression
     contains a variable which is not in the assignment, an exception
    is thrown.
     @param assignment the map with given varible values.
     @return true if the value of the expression is true, false if false
     */
    Boolean evaluate(Map<String, Boolean> assignment) throws Exception;

    /** A convenience method. Like the `evaluate(assignment)` method above,
    but uses an empty assignment (just with F and T).
     @return true if the value of the expression is true, false if false
     */
    Boolean evaluate() throws Exception;

    /** Returns a list of the variables in the expression.
     * @return List of string with the variables
     */
    List<String> getVariables();

    /** Returns a nice string representation of the expression.
     * @return String, the expression
     */
    String toString();

    /** Returns a new expression in which all occurrences of the variable
    var are replaced with the provided expression (Does not modify the
    current expression).
     @param var the var we want to assign
     @param expression the expression we want the var to asign to
     @return Expression the new expression after the assignment
     */
    Expression assign(String var, Expression expression);

    /**
     * Returns the expression tree resulting from converting all the operations to the logical Nand operation.
     * @return complex Nand expression
     */
    Expression nandify();

    /**
     * Returns the expression tree resulting from converting all the operations to the logical Nor operation.
     * @return complex Nor expression
     */
    Expression norify();

    /**
     * Returned a simplified version of the current expression.
     * @return a simpled expression
     */
    Expression simplify();

    /**
     * Return a copy of the expression.
     * @return new copy of expression
     */
    Expression createCopy();

    /**
     * return the same expression that its inner expression sorted by Lexicographic order.
     * @return sorted Expression
     */
    Expression sortString();
}
