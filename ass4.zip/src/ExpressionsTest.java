//Evyatar Altman 208060855

import java.util.Map;
import java.util.TreeMap;

/**
 * Class to test the whole assignment.
 */
public class ExpressionsTest {
    /**
     * main to run the assignment.
     * @param args none
     */
    public static void main(String[] args) throws Exception {
        Expression e = new And(new Xor(new Or(new Var("x"), new Var("z")), new Val(false)),
                new Nor(new Var("y"), new Val(true)));
        System.out.println(e);
        Map<String, Boolean> assignment = new TreeMap<>();
        assignment.put("x", true);
        assignment.put("y", false);
        assignment.put("z", false);
        //evaluate
        System.out.println(e.evaluate(assignment));
        //nandify
        System.out.println(e.nandify());
        //norify
        System.out.println(e.norify());
        //simplify
        System.out.println(e.simplify());
    }
}
