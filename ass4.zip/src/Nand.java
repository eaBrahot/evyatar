//Evyatar Altman 208060855

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * class that represent Nand expression.
 */
public class Nand extends BaseExpression {
    private static final String NAND = "A";
    private Expression left;
    private Expression right;

    /**
     * constructor with two expression.
     * @param left the left expression
     * @param right the right expression
     */
    public Nand(Expression left, Expression right) {
        this.left = left;
        this.right = right;
    }
    @Override
    public Boolean evaluate(Map<String, Boolean> assignment) throws Exception {
        //check if there is a false value
        return !left.evaluate(assignment) | !right.evaluate(assignment);
    }

    @Override
    public Boolean evaluate() throws Exception {
        //check if there is a false value
        return !left.evaluate() | !right.evaluate();
    }
    @Override
    public List<String> getVariables() {
        List<String> marge = new ArrayList<>();
        marge.addAll(left.getVariables());
        //check if i exists in the left operand
        for (String i : right.getVariables()) {
            if (!left.getVariables().contains(i)) {
                marge.add(i);
            }
        }
        return marge;
    }

    @Override
    public String toString() {
        return "(" + left.toString() + " " + NAND + " " + right.toString() + ")";
    }

    @Override
    public Expression assign(String var, Expression expression) {
        return new Nand(left.assign(var, expression), right.assign(var, expression));
    }

    @Override
    public Expression nandify() {
        return new Nand(left.nandify(), right.nandify());
    }

    @Override
    public Expression norify() {
        //xAy equals to ((x V x) V (y V y)) V ((x V x) V (y V y))
        return new Nor(new Nor(new Nor(left.norify(), left.norify()), new Nor(right.norify(), right.norify())),
                new Nor(new Nor(left.norify(), left.norify()), new Nor(right.norify(), right.norify())));
    }

    @Override
    public Expression simplify() {
        Expression left = this.left.simplify();
        Expression right = this.right.simplify();
        //x A 1 = ~(x)
        if (right.toString().equals("T")) {
            return new Not(left);
        }

        //1 A x = ~(x)
        if (left.toString().equals("T")) {
            return new Not(right);
        }
        //x A 0 = 1
        if (right.toString().equals("F")) {
            return new Val(true);
        }
        //0 A x = 1
        if (left.toString().equals("F")) {
            return new Val(true);
        }
        //x A x = ~(x)
        if (right.sortString().toString().equals(left.sortString().toString())) {
            return new Not(left);
        }
        //return the expression without change
        return new Nand(left, right);
    }

    @Override
    public Expression createCopy() {
        return new Nand(left.createCopy(), right.createCopy());
    }

    @Override
    public Expression sortString() {
        Expression left = this.left.sortString();
        Expression right = this.right.sortString();
        int first = 0;
        int result = left.toString().compareTo(right.toString());
        //if the left is lower
        if (result < 0) {
            return new Nand(right, left);
        }
        //without change
        return new Nand(left, right);
    }
}