//Evyatar Altman 208060855

import java.util.List;
import java.util.Map;

/**
 * class that represent Not (~) expression.
 */
public class Not extends UnaryExpression {
    private static final String NOT = "~";
    private Expression e;

    /**
     * constructor with given expression.
     * @param e expression
     */
    public Not(Expression e) {
        this.e = e;
    }
    @Override
    public Boolean evaluate(Map<String, Boolean> assignment) throws Exception {
        return !this.e.evaluate(assignment);
    }

    @Override
    public Boolean evaluate() throws Exception {
        return !this.e.evaluate();
    }

    @Override
    public List<String> getVariables() {
        return this.e.getVariables();
    }

    @Override
    public String toString() {
        return "~(" + e.toString() + ")";
    }

    @Override
    public Expression assign(String var, Expression expression) {
        return new Not(e.assign(var, expression));
    }

    @Override
    public Expression nandify() {
        //~(x) equals to x A x
        return new Nand(e.nandify(), e.nandify());
    }

    @Override
    public Expression norify() {
        //~(x) equals to x V x
        return new Nor(e.norify(), e.norify());
    }

    @Override
    public Expression simplify() {
        //There isn't rules about not
        return new Not(this.e.simplify());
    }

    @Override
    public Expression createCopy() {
        return new Not(e.createCopy());
    }

    @Override
    public Expression sortString() {
        return new Not(e.sortString());
    }
}
