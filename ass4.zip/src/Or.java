//Evyatar Altman 208060855

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * class that represent And expression.
 */
public class Or extends BinaryExpression {
    private static final String OR = "|";
    private Expression left;
    private Expression right;

    /**
     * constructor with two expression.
     * @param left the left expression
     * @param right the right expression
     */
    public Or(Expression left, Expression right) {
        this.left = left;
        this.right = right;
    }
    @Override
    public Boolean evaluate(Map<String, Boolean> assignment) throws Exception {
        return left.evaluate(assignment) || right.evaluate(assignment);
    }

    @Override
    public Boolean evaluate() throws Exception {
        return left.evaluate() || right.evaluate();
    }

    @Override
    public List<String> getVariables() {
        List<String> marge = new ArrayList<>();
        marge.addAll(left.getVariables());
        //check if i exists in the left operand
        for (String i : right.getVariables()) {
            if (!left.getVariables().contains(i)) {
                marge.add(i);
            }
        }
        return marge;
    }

    @Override
    public String toString() {
        return "(" + left.toString() + " " + OR + " " + right.toString() + ")";
    }

    @Override
    public Expression assign(String var, Expression expression) {
        return new Or(left.assign(var, expression), right.assign(var, expression));
    }

    @Override
    public Expression nandify() {
        //x|y equals to (x A x) A (y A y)
        return new Nand(new Nand(left.nandify(), left.nandify()), new Nand(right.nandify(), right.nandify()));
    }

    @Override
    public Expression norify() {
        //x&y equals to (x V y) A (x V y)
        return new Nor(new Nor(left.norify(), right.norify()), new Nor(left.norify(), right.norify()));
    }

    @Override
    public Expression simplify() {
        Expression left = this.left.simplify();
        Expression right = this.right.simplify();
        //x|T equals T
        if (right.toString().equals("T")) {
            return new Val(true);
        }
        //T|x equals T
        if (left.toString().equals("T")) {
            return new Val(true);
        }
        //x|F equals x
        if (right.toString().equals("F")) {
            return left.createCopy();
        }
        //F|x equals x
        if (left.toString().equals("F")) {
            return right.createCopy();
        }
        //x|x equals x
        if (right.sortString().toString().equals(left.sortString().toString())) {
            return left.createCopy();
        }
        //return the expression without change
        return new Or(left, right);
    }

    @Override
    public Expression createCopy() {
        return new Or(left.createCopy(), right.createCopy());
    }
    @Override
    public Expression sortString() {
        Expression left = this.left.sortString();
        Expression right = this.right.sortString();
        int first = 0;
        int result = left.toString().compareTo(right.toString());
        //if the left is lower
        if (result < 0) {
            return new Or(right, left);
        }
        //without change
        return new Or(left, right);
    }
}
