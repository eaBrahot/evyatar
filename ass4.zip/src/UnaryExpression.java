//Evyatar Altman 208060855

/**
 * abstract class that represent unary expression.
 */
public abstract class UnaryExpression extends BaseExpression {
}
