//Evyatar Altman 208060855

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Class to epresent value of true or false.
 */
public class Val implements Expression {
    private boolean val;

    /**
     * constructor to assign the val with boolean value.
     * @param b boolean value
     */
    public Val(boolean b) {
        this.val = b;
    }

    /**
     * get the boolean value of val.
     * @return boolean value of val
     */
    Boolean getVal() {
        return this.val;
    }

    /**
     * set the value of this val.
     * @param b boolean value
     */
    void setVal(boolean b) {
        this.val = b;
    }
    @Override
    public Boolean evaluate(Map<String, Boolean> assignment) throws Exception {
        //the evaluating is immediate
        return this.val;
    }

    @Override
    public String toString() {
        if (this.val) {
            return "T";
        }
        return "F";
    }
    @Override
    public Boolean evaluate() throws Exception {
        //the evaluating is immediate
        return this.val;
    }

    @Override
    public List<String> getVariables() {
        //there is no variables
        return new ArrayList<>();
    }

    @Override
    public Expression assign(String var, Expression expression) {
        //val has no variables, so it's always return himself
        return new Val(this.val);
        }

    @Override
    public Expression nandify() {
        //this is an atomic expression, there isn't what to convert
        return new Val(this.val);
    }

    @Override
    public Expression norify() {
        //this is an atomic expression, there isn't what to convert
        return new Val(this.val);
    }

    @Override
    public Expression simplify() {
        //this is an atomic expression, it's the simplest
        return new Val(this.val);
    }

    @Override
    public Expression createCopy() {
        return new Val(this.val);
    }

    @Override
    public Expression sortString() {
        return new Val(this.val);
    }
}

