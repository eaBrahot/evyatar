//Evyatar Altman 208060855

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * Class to represent variables that contain logical expressions.
 */
public class Var implements Expression {
    private String varExp;
    /**
     * costructor to build var with given string.
     * @param exp the string of the expression we want to assign to the var.
     */
    public Var(String exp) {
        this.varExp = exp;
    }

    /**
     * method to find string that not in a given list.
     * @param list of String
     * @return string that not in the list
     */
    private String findVarThatNotIn(List<String> list) {
        String[]unCommonVar = {"!", "@", "#", "$", "%", "^", "&", "*", "(", ")", "##", "@@", "!@#$@&$*#$$"};
        for (String i : unCommonVar) {
            if (!list.contains(i)) {
                return i;
            }
        }
        //not found, very low probability
        return null;
    }
    @Override
    public Boolean evaluate(Map<String, Boolean> assignment) throws Exception {
        //check if var in the assignment
        if (!assignment.containsKey(this.varExp)) {
            throw new Exception("Error, the expression\n"
                    + "contains a variable which is not in the assignment");
        }
        return assignment.get(this.varExp);
    }

    @Override
    public Boolean evaluate() throws Exception {
        //check if var is a variable
        if (!(this.varExp.equals("T") | this.varExp.equals("F"))) {
            throw new Exception("Error, the expression contains a variable");
        }
        //create assigment with T and F
        Map<String, Boolean> assignment = new HashMap<>();
        assignment.put("T", true);
        assignment.put("F", false);
        //check if var contain variables
        return assignment.get(this.varExp);
    }

    @Override
    public List<String> getVariables() {
        List<String> varList = new ArrayList<>();
        //add the var to the list
        varList.add(this.varExp);
        return varList;
    }

    @Override
    public Expression assign(String var, Expression expression) {
        //if the given var does not exist, return the current var
        if (!this.getVariables().contains(var)) {
            return new Var(this.varExp);
        }
         //if we have found, return new copy of the expression
         return expression.createCopy();
    }

    @Override
    public Expression nandify() {
        //this is an atomic expression, there isn't what to convert
        return new Var(this.varExp);
    }

    @Override
    public Expression norify() {
        //this is an atomic expression, there isn't what to convert
        return new Var(this.varExp);
    }

    @Override
    public String toString() {
        return this.varExp;
    }

    @Override
    public Expression simplify() {
        //this is an atomic expression, it's the simplest
        return new Var(this.varExp);
    }

    @Override
    public Expression createCopy() {
        return new Var(this.varExp);
    }

    @Override
    public Expression sortString() {
        return new Var(this.varExp);
    }
}
