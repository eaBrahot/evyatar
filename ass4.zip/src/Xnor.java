//Evyatar Altman 208060855

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * class that represent logical Xnor expression.
 */
public class Xnor extends BaseExpression {
    private static final String XNOR = "#";
    private Expression left;
    private Expression right;

    /**
     * constructor with two expression.
     * @param left the left expression
     * @param right the right expression
     */
    public Xnor(Expression left, Expression right) {
        this.left = left;
        this.right = right;
    }
    @Override
    public Boolean evaluate(Map<String, Boolean> assignment) throws Exception {
        //check if the values of the two are equal
        return left.evaluate(assignment) == right.evaluate(assignment);
    }

    @Override
    public Boolean evaluate() throws Exception {
        //check if there is a false value
        return left.evaluate() == right.evaluate();
    }

    @Override
    public List<String> getVariables() {
        List<String> marge = new ArrayList<>();
        marge.addAll(left.getVariables());
        //check if i exists in the left operand
        for (String i : right.getVariables()) {
            if (!left.getVariables().contains(i)) {
                marge.add(i);
            }
        }
        return marge;
    }

    @Override
    public String toString() {
        return "(" + left.toString() + " " + XNOR + " " + right.toString() + ")";
    }

    @Override
    public Expression assign(String var, Expression expression) {
        return new Xnor(left.assign(var, expression), right.assign(var, expression));
    }

    @Override
    public Expression nandify() {
        //x#y equals to ((x A x) A (y A y)) A (xAy)
        return new Nand(new Nand(new Nand(left.nandify(), left.nandify()), new Nand(right.nandify(), right.nandify())),
                new Nand(left.nandify(), right.nandify()));
    }

    @Override
    public Expression norify() {
        //x#y equals to (x V (x V y))V(y V (x V y))
        return new Nor(new Nor(left.norify(), new Nor(left.norify(), right.norify())),
                new Nor(right.norify(), new Nor(left.norify(), right.norify())));
    }

    @Override
    public Expression simplify() {
        Expression left = this.left.simplify();
        Expression right = this.right.simplify();
        //x#x equals T
        if (right.sortString().toString().equals(left.sortString().toString())) {
            return new Val(true);
        }
        //return the expression without change
        return new Xnor(left, right);
    }

    @Override
    public Expression createCopy() {
        return new Xnor(left.createCopy(), right.createCopy());
    }
    @Override
    public Expression sortString() {
        Expression left = this.left.sortString();
        Expression right = this.right.sortString();
        int first = 0;
        int result = left.toString().compareTo(right.toString());
        //if the left is lower
        if (result < 0) {
            return new Xnor(right, left);
        }
        //without change
        return new Xnor(left, right);
    }
}
