//Evyatar Altman 208060855

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * class that represent Xor expression.
 */
public class Xor extends BaseExpression {
    private static final String XOR = "^";
    private Expression left;
    private Expression right;

    /**
     * constructor with two expression.
     * @param left the left expression
     * @param right the right expression
     */
    public Xor(Expression left, Expression right) {
        this.left = left;
        this.right = right;
    }
    @Override
    public Boolean evaluate(Map<String, Boolean> assignment) throws Exception {
        return left.evaluate(assignment) ^ right.evaluate(assignment);
    }

    @Override
    public Boolean evaluate() throws Exception {
        return left.evaluate() ^ right.evaluate();
    }

    @Override
    public List<String> getVariables() {
        List<String> marge = new ArrayList<>();
        marge.addAll(left.getVariables());
        //check if i exists in the left operand
        for (String i : right.getVariables()) {
            if (!left.getVariables().contains(i)) {
                marge.add(i);
            }
        }
        return marge;
    }

    @Override
    public String toString() {
        return "(" + left.toString() + " " + XOR + " " + right.toString() + ")";
    }

    @Override
    public Expression assign(String var, Expression expression) {
        return new Xor(left.assign(var, expression), right.assign(var, expression));
    }

    @Override
    public Expression nandify() {
        //x^y equals to (x A (x A y)) A (y A (x A y))
        return new Nand(new Nand(left.nandify(), new Nand(left.nandify(), right.nandify())),
                new Nand(right.nandify(), new Nand(left.nandify(), right.nandify())));
    }

    @Override
    public Expression norify() {
        //x^y equals to ((x V x) V (y V y)) V (x V y)
        return new Nor(new Nor(new Nor(left.norify(), left.norify()), new Nor(right.norify(), right.norify())),
                new Nor(left.norify(), right.norify()));
    }

    @Override
    public Expression simplify() {
        Expression left = this.left.simplify();
        Expression right = this.right.simplify();
        //x ^ 1 = ~(x)
        if (right.toString().equals("T")) {
            return new Not(left);
        }
        //1 ^ x = ~(x)
        if (left.toString().equals("T")) {
            return new Not(right);
        }
        //x ^ 0 = x
        if (right.toString().equals("F")) {
            return left.createCopy();
        }
        //0 ^ x = x
        if (left.toString().equals("F")) {
            return right.createCopy();
        }
        //x ^ x = 0
        if (right.sortString().toString().equals(left.sortString().toString())) {
            return new Val(false);
        }
        //return the expression without change
        return new Xor(left, right);
    }

    @Override
    public Expression createCopy() {
        return new Xor(left.createCopy(), right.createCopy());
    }
    @Override
    public Expression sortString() {
        Expression left = this.left.sortString();
        Expression right = this.right.sortString();
        int first = 0;
        int result = left.toString().compareTo(right.toString());
        //if the left is lower
        if (result < 0) {
            return new Xor(right, left);
        }
        //without change
        return new Xor(left, right);
    }
}
