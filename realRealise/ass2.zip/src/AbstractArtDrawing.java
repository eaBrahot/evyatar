//208060855 Evyatar Altman

import biuoop.GUI;
import biuoop.DrawSurface;

import java.util.Random;
import java.awt.Color;

/**
 * AbstractArtDrawing can draw lines on a given board and draw their middle and intersections.
 */
public class AbstractArtDrawing {
    //the radius of the middle\intersection points
    private static final int R = 3;

    /**
     * this method draw random lines and draw their middle points and intersections.
     */
    public void drawRandomLines() {
        Random rand = new Random(); // create a random-number generator
        // Create a window with the title "Random Circles Example"
        // which is 400 pixels wide and 300 pixels high.
        GUI gui = new GUI("Random Lines Example", 400, 300);
        DrawSurface d = gui.getDrawSurface();
        Line[] arrOfTheLines = new Line[10];
        for (int i = 0; i < 10; ++i) {
            int x = rand.nextInt(400); // get integer in range 400
            int y = rand.nextInt(300); // get integer in range 300
            int z = rand.nextInt(400); // get integer in range 400
            int w = rand.nextInt(300); // get integer in range 300
            d.setColor(Color.DARK_GRAY);
            d.drawLine(x, y, z, w);
            //add the line to the arry
            arrOfTheLines[i] = new Line(x, y, z, w);
            //take the middle point and draw red circle that represent it
            Point m = arrOfTheLines[i].middle();
            d.setColor(Color.BLUE);
            d.fillCircle((int) m.getX(), (int) m.getY(), R);
            //run on the other lines and draw their intersections
            d.setColor(Color.RED);
            Point inter;
            for (int j = 0; j < i; j++) {
                //take their intersection point
                inter = arrOfTheLines[i].intersectionWith(arrOfTheLines[j]);
                if (inter != null) {
                    d.fillCircle((int) inter.getX(), (int) inter.getY(), R);
                }
            }
        }
        gui.show(d);
    }

    /**
     * main operate the drawAnimation method.
     * @param args parameters from cmd
     */
    public static void main(String[] args) {
        AbstractArtDrawing example = new AbstractArtDrawing();
        example.drawRandomLines();
    }
}

