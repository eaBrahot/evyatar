//208060855 Evyatar Altman

/**
 * Ball represent 2D ball (actually, a circle). Balls have size (radius), color, and location (a Point).
 * Balls also know how to draw themselves on a given DrawSurface.
 */
import biuoop.DrawSurface;

import java.awt.Color;

/**
 * all the members of the ball. include radius, center point,color, velocity and his limits (borders)
 */
    public class Ball {
        private Point center;
        private int r;
        private Color color;
        //default v is zero
        private Velocity v = new Velocity(0, 0);
        //the default borders are the screen of (0,0) on (200,200)
        private int xStart = 0;
        private int xBorder = 200;
        private int yStart = 0;
        private int yBorder = 200;

    //check if the r is in the frame of the screen
    private int rLegal() {
        //deference of the lowest borders divided by 2.
        int maxR = (Math.min(this.xBorder, this.yBorder) - Math.min(this.xStart, this.yStart)) / 2;
        return Math.min(this.r, maxR);
    }
    //check if the center is not out of the borders of the screen
    private Point centerLegal() {
        int r = this.r;
        Point center = this.center;
        double fixedX = this.center.getX();
        double fixedY = this.center.getY();
        //check the right border
        if (center.getX() > this.xBorder) {
            fixedX = this.xBorder - r;
        }
        //check the left
        if (center.getX() < this.xStart) {
            fixedX = r;
        }
        //check the bottom
        if (center.getY() > this.yBorder) {
            fixedY = this.yBorder - r;
    }
        //check the up
        if (center.getY() < this.yStart) {
            fixedY = r;
        }
        return new Point(fixedX, fixedY);
    }

    /**
     * constructor with point.
     * @param center point
     * @param r radius
     * @param color of the ball
     */
    public Ball(Point center, int r, java.awt.Color color) {
        this.r = r;
        //after we have r, we can check him
        this.r = this.rLegal();
        this.center = center;
        //after we have center, we can check it
        this.center = this.centerLegal();
        this.color = color;
    }

    /**
     * constrctor with x and y.
     * @param x of the center
     * @param y of the center
     * @param r radius
     * @param color of the ball
     */
    public Ball(int x, int y, int r, java.awt.Color color) {
        this.center = new Point(x, y);
        //after we have center, we can check it
        this.center = this.centerLegal();
        this.r = r;
        //after we have r, we can check him
        this.r = this.rLegal();
        this.color = color;
    }

    /**
     * constructor with limits of the screen. the start of the screen is in default (0,0).
     * @param center of the ball
     * @param r radius
     * @param color of the ball
     * @param xBorder limit from right
     * @param yBorder limit from down
     */
    public Ball(Point center, int r, java.awt.Color color, int xBorder, int yBorder) {
        this.xBorder = xBorder;
        this.yBorder = yBorder;
        this.center = center;
        //after we have center, we can check it
        this.center = this.centerLegal();
        this.r = r;
        //after we have r, we can check him
        this.r = this.rLegal();
        this.color = color;

    }

    /**
     * constructor with limits of the screen. the start of the screen is in default (0,0).
     * @param x of the center of the ball
     * @param y of the center of the ball
     * @param r radius
     * @param color of the ball
     * @param xBorder limit from right
     * @param yBorder limit from down
     */
    //with x and y
    public Ball(int x, int y, int r, java.awt.Color color, int xBorder, int yBorder) {
        this.xBorder = xBorder;
        this.yBorder = yBorder;
        this.center = new Point(x, y);
        //after we have center, we can check it
        this.center = this.centerLegal();
        this.r = r;
        //after we have r, we can check him
        this.r = this.rLegal();
        this.color = color;
    }

    /**
     * constructor with limits of the ball.
     * @param x of the center of the ball
     * @param y of the center of the ball
     * @param r radius
     * @param color of the ball
     * @param upLeftLimits x for left, y for up
     * @param rightDownLimit x for right, y for down
     */
    public Ball(int x, int y, int r, java.awt.Color color, Point upLeftLimits, Point rightDownLimit) {
        this.xStart = (int) upLeftLimits.getX();
        this.yStart = (int) upLeftLimits.getY();
        this.xBorder = (int) rightDownLimit.getX();
        this.yBorder = (int) rightDownLimit.getY();
        this.center = new Point(x, y);
        //after we have center, we can check it
        this.center = this.centerLegal();
        this.r = r;
        //after we have r, we can check him
        this.r = this.rLegal();
        this.color = color;
    }

    /**
     * access to the x of the center.
     * @return int, the x of the center
     */
    public int getX() {
     return (int) this.center.getX();
    }

    /**
     * access to the y of the center.
     * @return int the y of the center
     */
    public int getY() {
        return (int) this.center.getY();
    }

    /**
     * access to the r of the ball.
     * @return int, the r
     */
    //get the radius of the ball
    public int getSize() {
        return r;
    }

    /**
     * access to the color of the ball.
     * @return Color.
     */
    public java.awt.Color getColor() {
        return this.color;
    }

    /**
     * draw the ball on the given DrawSurface.
     * @param surface which we want to draw on
     */
    public void drawOn(DrawSurface surface) {
        surface.setColor(this.color);
        surface.fillCircle(this.getX(), this.getY(), this.r);
    }

    /**
     * setter to give the ball velocity.
     * @param v the velocity we want to give the ball.
     */
    public void setVelocity(Velocity v) {
        this.v = v;
    }

    /**
     * setter to give the ball velocity with dx and dy.
     * @param dx double, change in x
     * @param dy double, change in y
     */
    public void setVelocity(double dx, double dy) {
        this.v = new Velocity(dx, dy);
    }

    /**
     * getter to get the ball's velocity.
     * @return v, velocity of the ball
     */
    public Velocity getVelocity() {
        return this.v;
    }

    /**
     * give the ball "speed" by changing his center point with his velocity.
     */
    public void moveOneStep() {
        double r = this.r;
        double x = this.center.getX();
        double y = this.center.getY();
        double dx = this.v.getDx();
        double dy = this.v.getDy();
        //check if the ball almost getting to the borders
            //get the ball to the border and turn his detraction
        //check to the right down corner
        if (x + r + dx >= this.xBorder && y + r + dy >= this.yBorder) {
            this.center = new Point(xBorder - r, yBorder - r);
            this.v = new Velocity(-dx, -dy);
            //check to the left up corner
        } else if (x - r + dx <= xStart && y - r + dy <= yStart) {
            this.center = new Point(xStart + r, yStart + r);
            this.v = new Velocity(-dx, -dy);
            //check to the left down corner
        } else if (x - r + dx <= xStart && y + r + dy >= this.yBorder) {
            this.center = new Point(xStart + r, yBorder - r);
            this.v = new Velocity(-dx, -dy);
            //check to the right up corner
        } else if (x + r + dx >= this.xBorder && y - r + dy <= yStart) {
            this.center = new Point(xBorder - r,  yStart + r);
            this.v = new Velocity(-dx, -dy);
            //check to the right border
        } else if (x + r + dx >= this.xBorder) {
            this.center = new Point(xBorder - r, y);
            this.v = new Velocity(-dx, dy);
            //check to the left border
        } else if (x - r + dx <= xStart) {
            this.center = new Point(xStart + r, y);
            this.v = new Velocity(-dx, dy);
            //check to the bottom
        } else if (y + r + dy >= this.yBorder) {
            this.center = new Point(x, yBorder - r);
            this.v = new Velocity(dx, -dy);
            //check to the roof
        } else if (y - r + dy <= yStart) {
            this.center = new Point(x, yStart + r);
            this.v = new Velocity(dx, -dy);
            //keep the regular v
        } else {
            this.center = this.getVelocity().applyToPoint(this.center);
        }
    }
}
