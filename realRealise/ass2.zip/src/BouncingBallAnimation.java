//208060855 Evyatar Altman

import biuoop.GUI;
import biuoop.DrawSurface;
import biuoop.Sleeper;

/**
 * This class operate animation of moving ball in radius of 30 that not get out from
 * the limits of the screen ((0,0),(200,200)).
 */
public class BouncingBallAnimation {
    private static final int WIGHT = 200;
    private static final int HIGHT = 200;
    private static final int R = 30;

    /**
     * The method gets start point for the center of the ball and dx, dy for the velocity we want to give him.
     * @param start the first point there we put the ball
     * @param dx change in x
     * @param dy change in y
     */
    private static void drawAnimation(Point start, double dx, double dy) {
        GUI gui = new GUI("title", WIGHT, HIGHT);
        Sleeper sleeper = new Sleeper();
        Ball ball = new Ball((int) start.getX(), (int) start.getY(), R, java.awt.Color.BLACK, WIGHT, HIGHT);
        ball.setVelocity(dx, dy);
        while (true) {
            DrawSurface d = gui.getDrawSurface();
            ball.moveOneStep();
            ball.drawOn(d);
            gui.show(d);
            sleeper.sleepFor(50);  // wait for 50 milliseconds.
        }
    }

    /**
     * main gets pram from the cmd of the start point(x,y) of the ball and his
     * velocity (dx,dy).
     * @param args from the cmd
     */
    public static void main(String[] args) {
        //convert the string to double
        double x = Double.parseDouble(args[0]);
        double y = Double.parseDouble(args[1]);
        double dx = Double.parseDouble(args[2]);
        double dy = Double.parseDouble(args[3]);

        drawAnimation(new Point(x, y), dx, dy);
    }
}
