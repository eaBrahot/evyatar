//208060855 Evyatar Altman
import biuoop.DrawSurface;
import biuoop.GUI;
import biuoop.Sleeper;

import java.awt.Color;
import java.util.Random;

/**
 * This class draw animation of multiple balls in a screen with size of (0,0) to (450,450).
 */
public class MultipleBouncingBallsAnimation {
    //the borders of the screen
    private static final int XSTART = 0;
    private static final int WIGHT = 450;
    private static final int YSTART = 0;
    private static final int HEIGHT = 450;
    private static final int MIN_SPEED = 50;
    private static final int MAX_SPEED = 75;

    /**
     *method to create array of balls from the args.
     * @param args para from cmd
     * @param xStart the limit to the left
     * @param wight the limit to right
     * @param yStart the limit to the top
     * @param height the limit to the bottom
     * @return Ball[], arry of balls
     */
    public static Ball[] createArrayOfBalls(String[] args, int xStart, int wight, int yStart, int height) {
        Random rand = new Random();
        Ball[] balls = new Ball[args.length];
        //create ball from each size
        int i = 0;
        for (String j : args) {
            //convert the r
            int r = Integer.parseInt(j);
            //create random color
            //for red
            int re = rand.nextInt(255) + 1;
            //green
            int g = rand.nextInt(255) + 1;
            //blue
            int b = rand.nextInt(255) + 1;
            Color c = new Color(re, g, b);
            //x and y inside the borders
            int x = rand.nextInt(WIGHT) + xStart;
            int y = rand.nextInt(HEIGHT) + yStart;
            Point leftUp = new Point(xStart, yStart);
            Point rightDown = new Point(wight, height);
            balls[i] = new Ball(x, y, r, c, leftUp, rightDown);
            //The smaller the ball the rapid he is. balls the size of 50 and though are in the same speed of 25
            double speed = Math.max(MAX_SPEED - r * 0.5, MIN_SPEED);
            //create random angle. random radians
            double angle = rand.nextDouble();
            Velocity v = Velocity.fromAngleAndSpeed(angle, speed);
            balls[i].setVelocity(v);
            i++;
        }
        return balls;
    }

    /**
     * method to draw all the balls which we got their r's from the cmd.
     * @param args param from cmd
     */
    private static void drawAnimation(String[] args) {
        //create array of balls with the parameters from cmd
        Ball[] balls = createArrayOfBalls(args, XSTART, WIGHT, YSTART, HEIGHT);
        //craete new board of (0,0) to (450,450)
        GUI gui = new GUI("MultipleBouncingBallsAnimation", WIGHT, HEIGHT);
        Sleeper sleeper = new Sleeper();
        //loop to operate the animation
        while (true) {
            DrawSurface d = gui.getDrawSurface();
            //draw each ball in the array
            for (Ball ball : balls) {
                //move the ball and draw it
                ball.moveOneStep();
                ball.drawOn(d);
            }
            sleeper.sleepFor(50);  // wait for 50 milliseconds.
            gui.show(d);
        }

    }

    /**
     * the main take args from cmd and operate the drawAnimation method.
     * @param args radius from the cmd
     */
    public static void main(String[] args) {
        drawAnimation(args);
    }
}
