//208060855 Evyatar Altman
import biuoop.DrawSurface;
import biuoop.GUI;
import biuoop.Sleeper;

import java.awt.Color;

/**
 * This class draw animation of several balls which we got their radius's from the cmd and draw
 * half in big grey rectangle ( (50,50) to (500,500)) and the over half in small yellow rectangle
 * ( (450,450) to (600,600)) in big screen ((0,0) to (900,900) ).
 */
public class MultipleFramesBouncingBallsAnimation {
    private static final int WIGHT = 900;
    private static final int HEIGHT = 900;
    private static final int X1GREY = 50;
    private static final int Y1GREY = 50;
    private static final int X2GREY = 500;
    private static final int Y2GREY = 500;
    private static final int X1YEL = 450;
    private static final int Y1YEL = 450;
    private static final int X2YEL = 600;
    private static final int Y2YEL = 600;

    /**
     * method that split the args to draw one half of the balls in the grey and the over in the yellow.
     * @param args param from cmd
     * @return array of balls, half in the grey ractangle and half in the yellow
     */
    private static Ball[] createBallsWithTheLImitsOfTheRec(String[] args) {
        int len = args.length;
        String[] args1;
        String[] args2;
        //if the num of the balls is even
        if (len % 2 == 0) {
            args1 = new String[len / 2];
            args2 = new String[len / 2];
            //if they odd
        } else {
            args1 = new String[(len - 1) / 2];
            args2 = new String[(len - 1) / 2 + 1];
        }
        int i = 0;
        //keep the first half in arg1 and the rest in arg2
        while (i < len) {
            for (int j = 0; j < args1.length; j++, i++) {
                args1[j] = args[i];
            }
            for (int j = 0; i < len; j++, i++) {
                args2[j] = args[i];
            }
        }
        //create array of balls from arg1 for the grey and from arg2 for the yellow
        Ball[] balls1 = MultipleBouncingBallsAnimation.createArrayOfBalls(args1, X1GREY, X2GREY,
                Y1GREY, Y2GREY);
        Ball[] balls2 = MultipleBouncingBallsAnimation.createArrayOfBalls(args2, X1YEL, X2YEL,
                Y1YEL, Y2YEL);
        //create new array for all the balls
        Ball[] balls = new Ball[len];
        i = 0;
        //keep all the balls in the big array
        while (i < len) {
            for (int j = 0; j < balls1.length; j++, i++) {
                balls[i] = balls1[j];
        }
            for (int j = 0; i < len; j++, i++) {
                balls[i] = balls2[j];
            }
        }
        return balls;
    }

    /**
     * method to draw the balls and their rectangles.
     * @param args param from cmd
     */
    public static void drawAnimationRec(String[] args) {
        //create array of balls from the radius in args
        Ball[] balls = createBallsWithTheLImitsOfTheRec(args);
        //create screen
        GUI gui = new GUI("MultipleFramesBouncingBallsAnimation", WIGHT, HEIGHT);
        Sleeper sleeper = new Sleeper();
        //loop for the animation
        while (true) {
            //create board
            DrawSurface d = gui.getDrawSurface();
            //draw the grey rectangle
            d.setColor(Color.GRAY);
            //The grey is get draw until the yello
            d.fillRectangle(X1GREY, Y1GREY, X1YEL, Y1YEL);
            //draw the yellow rectangle
            d.setColor(Color.YELLOW);
            //his edges are the deference between his start and end coordination
            d.fillRectangle(X1YEL, Y1YEL, X2YEL - X1YEL, Y2YEL - Y1YEL);
            //draw each ball in the array
            for (Ball ball : balls) {
                ball.moveOneStep();
                ball.drawOn(d);
            }
            sleeper.sleepFor(50);  // wait for 50 milliseconds.
            gui.show(d);
        }

    }

    /**
     * the main take args from cmd and operate the drawAnimation method.
     * @param args radius from the cmd
     */
    public static void main(String[] args) {
        drawAnimationRec(args);
    }
}
